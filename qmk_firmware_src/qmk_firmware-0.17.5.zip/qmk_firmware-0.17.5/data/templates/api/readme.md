# QMK Keyboard Metadata

This directory contains machine parsable data about keyboards supported by QMK. The latest version is always available online at <https://keyboards.qmk.fm>.

Do not edit anything here by hand. It is generated with the `qmk generate-api` command.
